package shoppingcart;

public enum CartAction{
    Add,
    Remove,
    Print;
}