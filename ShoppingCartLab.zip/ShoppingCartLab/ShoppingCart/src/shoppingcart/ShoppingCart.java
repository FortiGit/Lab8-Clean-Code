package shoppingcart;

import java.util.ArrayList;

import java.util.Iterator;

import products.Product;

public class ShoppingCart {
	ArrayList<CartLine> list = new ArrayList<CartLine>();

	public void action(Product product, CartAction action) {
		if (action == CartAction.Add) {
			addProduct(product);
		} else {
			if (action == CartAction.Remove) {
				removeProduct(product);
			} else { // action is print
				printCart();
			}
		}
	}

	public double getTotal() {
		double totalPrice = 0.0;
		for (CartLine cartLine : list) {
			totalPrice = totalPrice + (cartLine.getProduct().getPrice() * cartLine.getQuantity());
		}
		return totalPrice;
	}

	private void addProduct(Product product) {
		for (CartLine cline : list) {
			if (cline.getProduct().getProductnumber().equals(product.getProductnumber())) {
				cline.setQuantity(cline.getQuantity() + 1);
				return;
			}
		}
		CartLine cline = new CartLine();
		cline.setProduct(product);
		cline.setQuantity(1);
		list.add(cline);
	}

	private void removeProduct(Product product) {
		Iterator<CartLine> iter = list.iterator();
		while (iter.hasNext()) {
			CartLine cline = iter.next();
			if (cline.getProduct().getProductnumber().equals(product.getProductnumber())) {
				if (cline.getQuantity() > 1) {
					cline.setQuantity(cline.getQuantity() - 1);
				} else {
					iter.remove();
				}
			}
		}
	}

	private void printCart() {
		System.out.println("Content of the shoppingcart:");
		for (CartLine cline : list) {
			System.out.println(cline.getQuantity() + " "
					+ cline.getProduct().getProductnumber() + " "
					+ cline.getProduct().getDescription() + " "
					+ cline.getProduct().getPrice());
		}
		System.out.println("Total price =" + getTotal());
	}
}
