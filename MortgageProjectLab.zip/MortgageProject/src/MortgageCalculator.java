import java.time.LocalDate;
import java.time.Period;

public class MortgageCalculator {
	private final int DEFAULT_RESULT_VALUE = 0;
	private final int MAX_MORTGAGE_LOW_1 = 120000;
	private final int MAX_MORTGAGE_LOW_2 = 160000;
	private final int MAX_MORTGAGE_LOW_3 = 220000;
	private final int MAX_MORTGAGE_MEDIUM_1 = 140000;
	private final int MAX_MORTGAGE_MEDIUM_2 = 180000;
	private final int MAX_MORTGAGE_MEDIUM_3 = 250000;
	private final int MAX_MORTGAGE_HIGH_1 = 160000;
	private final int MAX_MORTGAGE_HIGH_2 = 220000;
	private final int MAX_MORTGAGE_HIGH_3 = 280000;
	private final double MARRIED_MORTGAGE_PERCENTAGE = 0.94;

	public double computeMaxMortgage(Mortgagor mortgagor) {
		double result = DEFAULT_RESULT_VALUE;

		int age = this.calculateAge(mortgagor.getYearOfBirth(), mortgagor.getMonth(), mortgagor.getDay());

		if (!isAdult(age)) {
			result = 0;
		} else {
			if (!mortgagor.isMarried()) {
				result = computeAdultMortgage(mortgagor.getProfession(), getJobCategory(mortgagor.getMonthlyIncome()));

			} else {
				double totalIncome = mortgagor.getMonthlyIncome()
						+ mortgagor.getMonthlyIncomePartner() * MARRIED_MORTGAGE_PERCENTAGE;
				result = computeAdultMortgage(mortgagor.getProfession(), getJobCategory(totalIncome));
			}
		}

		return result;
	}

	private boolean isAdult(int age) {
		return age > 18;
	}

	private JobCategory getJobCategory(double income) {
		if (2000 <= income && income < 3000) {
			return JobCategory.LowPaying;
		}
		if (3000 <= income && income < 5000) {
			return JobCategory.MediumPaying;
		}
		if (5000 <= income) {
			return JobCategory.HighPaying;
		}
		throw new IllegalArgumentException("Invalid income amount specified");
	}

	private double computeAdultMortgage(Profession profession, JobCategory category) {
		double result = DEFAULT_RESULT_VALUE;
		if (category == JobCategory.LowPaying) {
			switch (profession) {
				case Developer:
				case Architect:
				case ScrumMaster:
					result = MAX_MORTGAGE_LOW_2;
					break;
				case Tester:
				case SystemAdministrator:
				case TechnicalWriter:
					result = MAX_MORTGAGE_LOW_1;
					break;
				case DepartmentHead:
				case Professor:
					result = MAX_MORTGAGE_LOW_3;
					break;
			}
		}
		if (category == JobCategory.MediumPaying) {
			switch (profession) {
				case Developer:
				case Architect:
				case ScrumMaster:
					result = MAX_MORTGAGE_MEDIUM_2;
					break;
				case Tester:
				case SystemAdministrator:
				case TechnicalWriter:
					result = MAX_MORTGAGE_MEDIUM_1;
					break;
				case DepartmentHead:
				case Professor:
					result = MAX_MORTGAGE_MEDIUM_3;
					break;
			}
		}
		if (category == JobCategory.HighPaying) {
			switch (profession) {
				case Developer:
				case Architect:
				case ScrumMaster:
					result = MAX_MORTGAGE_HIGH_2;
					break;
				case Tester:
				case SystemAdministrator:
				case TechnicalWriter:
					result = MAX_MORTGAGE_HIGH_1;
					break;
				case DepartmentHead:
				case Professor:
					result = MAX_MORTGAGE_HIGH_3;
					break;
			}
		}
		return result;
	}

	private int calculateAge(int year, int month, int day) {
		LocalDate todayDate = LocalDate.now();
		LocalDate birthdayDate = LocalDate.of(year, month, day);

		Period p = Period.between(birthdayDate, todayDate);
		int age = p.getYears();
		System.out.println(age);

		return age;
	}

}
