public enum Profession {
    Developer ("Developer"),
    Architect ("Architect"),
    ScrumMaster("Scrum master"),
    Tester("Tester"),
    SystemAdministrator("System Administrator"),
    TechnicalWriter("Technical writer"),
    DepartmentHead("Department head"),
    Professor("Professor");

    private final String value;
    
    Profession(String value){
        this.value=value;
    }
    @Override
    public String toString(){
        return this.value;
    }

    public boolean equals(Profession profession){
        return this.toString().equals(profession.toString());
    }

}
