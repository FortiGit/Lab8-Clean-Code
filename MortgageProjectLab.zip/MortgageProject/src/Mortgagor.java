public class Mortgagor {
    private int yearOfBirth;
    private int month;
    private int day;
    private double monthlyIncome;
    private boolean married;
    private double monthlyIncomePartner;
    private Profession profession;

    public Mortgagor(int yearOfBirth, int month, int day, double monthlyIncome, boolean married, double monthlyIncomePartner, Profession profession){
        this.yearOfBirth=yearOfBirth;
        this.month=month;
        this.day=day;
        this.monthlyIncome=monthlyIncome;
        this.married=married;
        this.monthlyIncomePartner=monthlyIncomePartner;
        this.profession=profession;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }
    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }
    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public boolean isMarried(){
        return this.married;
    }
    public void setMarried(boolean married) {
        this.married = married;
    }

    public double getMonthlyIncomePartner() {
        return monthlyIncomePartner;
    }
    public void setMonthlyIncomePartner(double monthlyIncomePartner) {
        this.monthlyIncomePartner = monthlyIncomePartner;
    }

    public Profession getProfession() {
        return profession;
    }
    public void setProfession(Profession profession) {
        this.profession = profession;
    }

}
