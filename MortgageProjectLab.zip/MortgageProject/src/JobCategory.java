public enum JobCategory {
    LowPaying,
    MediumPaying,
    HighPaying
}

